package com.example.nataliaseventtrackingapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {

    private GridView dataGridView;
    private Button addDataButton;
    private DatabaseHelper dbHelper;
    private SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new DatabaseHelper(this);

        dataGridView = findViewById(R.id.dataGridView);
        addDataButton = findViewById(R.id.addDataButton);

        displayData();

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addData();
            }
        });
    }

    private void displayData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.DATA_TABLE,
                new String[]{DatabaseHelper.COLUMN_ID, DatabaseHelper.COLUMN_EVENT, DatabaseHelper.COLUMN_DATE},
                null, null, null, null, null
        );

        if (cursor != null) {
            String[] from = {DatabaseHelper.COLUMN_EVENT, DatabaseHelper.COLUMN_DATE};
            int[] to = {android.R.id.text1, android.R.id.text2};

            adapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, cursor, from, to, 0);
            dataGridView.setAdapter(adapter);
        }
    }

    private void addData() {
        // Implement your logic to add data to the database
        Toast.makeText(this, "Add Data button clicked", Toast.LENGTH_SHORT).show();
    }
}

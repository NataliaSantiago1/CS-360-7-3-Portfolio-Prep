package com.example.nataliaseventtrackingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private GridView dataGrid;
    private Button addDataButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataGrid = findViewById(R.id.dataGrid);
        addDataButton = findViewById(R.id.addDataButton);

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle adding data
                addDataToGrid();
            }
        });
    }

    private void addDataToGrid() {
        // Add data to grid
        Toast.makeText(MainActivity.this, "Data added to grid", Toast.LENGTH_SHORT).show();
    }
}
